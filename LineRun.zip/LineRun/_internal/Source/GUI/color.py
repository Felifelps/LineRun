class Color:
    #Basics
    black = [0, 0, 0]
    white = [255, 255, 255]

    #Game pallete
    main_purple = [163, 73, 164]
    middle_purple = [202, 69, 203]
    ligther_purple = [200, 191, 231]
    especial_red = [237, 28, 36] 

        
