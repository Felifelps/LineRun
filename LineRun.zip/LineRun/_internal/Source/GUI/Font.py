class Font:
    font_string = "Impact"
    font_size = 40